// Flight ticket booking.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <iomanip>

class Passenger {
public:
    std::string name;
    std::string ticketType;
    std::string mealPreference;
    int seatNumber;
    double price;

	Passenger(){};
    Passenger(const std::string& name, const std::string& ticketType, const std::string& mealPreference, int seatNumber, double price)
        : name(name), ticketType(ticketType), mealPreference(mealPreference), seatNumber(seatNumber), price(price) {}
};

class Flight {
public:
    std::string id;
    int totalSeats;
    int availableSeats;
    double basePrice;
    double currentPrice;
    double totalRevenue;
    std::map<int, Passenger> seatMap;

	Flight(){};
    Flight(const std::string& id, int totalSeats, double basePrice)
        : id(id), totalSeats(totalSeats), availableSeats(totalSeats), basePrice(basePrice), currentPrice(basePrice), totalRevenue(0) {}

    bool bookTicket(const std::string& passengerName, const std::string& ticketType, const std::string& mealPreference) {
        if (availableSeats <= 0) {
            std::cout << "No seats available on flight " << id << std::endl;
            return false;
        }
        int seatNumber = totalSeats - availableSeats + 1;
        availableSeats--;
        double ticketPrice = currentPrice;
        Passenger passenger(passengerName, ticketType, mealPreference, seatNumber, ticketPrice);
        seatMap[seatNumber] = passenger;

        // Surge pricing: increase price by 5% with each booking
        totalRevenue += ticketPrice;
        currentPrice *= 1.05;
        std::cout << "Booking successful! Seat number: " << seatNumber << ", Price: Rs. " << ticketPrice << std::endl;
        return true;
    }

    bool cancelTicket(int seatNumber) {
        if (seatMap.find(seatNumber) == seatMap.end()) {
            std::cout << "Invalid seat number!" << std::endl;
            return false;
        }

        Passenger passenger = seatMap[seatNumber];
        std::cout << "Cancelling ticket for " << passenger.name << std::endl;

        // Process refund (For simplicity, refunding the full amount)
        totalRevenue -= passenger.price;
        availableSeats++;

        // Remove passenger from seat map
        seatMap.erase(seatNumber);
        return true;
    }

    void flightSummary() {
        std::cout << "Flight ID: " << id << std::endl;
        std::cout << "Total Seats: " << totalSeats << ", Available Seats: " << availableSeats << std::endl;
        std::cout << "Total Revenue: Rs. " << std::fixed << std::setprecision(2) << totalRevenue << std::endl;
        std::cout << "Passenger List:" << std::endl;

        for (std::map<int, Passenger>::iterator it = seatMap.begin(); it != seatMap.end(); ++it) {
			int seat = it->first;  // Extract the seat number
			Passenger passenger = it->second;  // Extract the Passenger object

			std::cout << "Seat: " << seat << ", Name: " << passenger.name 
					  << ", Ticket Type: " << passenger.ticketType
					  << ", Meal: " << passenger.mealPreference
					  << ", Price: Rs. " << passenger.price << std::endl;
		}
        std::cout << "---------------------------------" << std::endl;
    }
};

class FlightBookingSystem {
public:
    std::map<std::string, Flight> flights;

    FlightBookingSystem() {
        // Initialize two flights with base prices
        flights["A001"] = Flight("A001", 10, 100.0);
        flights["A002"] = Flight("A002", 15, 120.0);
    }

    void bookTicket(const std::string& flightId, const std::string& passengerName, const std::string& ticketType, const std::string& mealPreference) {
        if (flights.find(flightId) != flights.end()) {
            flights[flightId].bookTicket(passengerName, ticketType, mealPreference);
        } else {
            std::cout << "Flight not found!" << std::endl;
        }
    }

    void cancelTicket(const std::string& flightId, int seatNumber) {
        if (flights.find(flightId) != flights.end()) {
            flights[flightId].cancelTicket(seatNumber);
        } else {
            std::cout << "Flight not found!" << std::endl;
        }
    }

    void showFlightSummary(const std::string& flightId) {
        if (flights.find(flightId) != flights.end()) {
            flights[flightId].flightSummary();
        } else {
            std::cout << "Flight not found!" << std::endl;
        }
    }
};

int main() {
    FlightBookingSystem system;

    // Sample bookings
    system.bookTicket("A001", "Vignesh", "Economy", "Vegetarian");
    system.bookTicket("A001", "Balaji", "Business", "Non-Vegetarian");
    system.bookTicket("A002", "Sathish", "Economy", "Vegan");

    // Show flight summary
    std::cout << "\nFlight Summary A001:" << std::endl;
    system.showFlightSummary("A001");

    // Cancel a booking
    system.cancelTicket("A001", 1);

    // Show flight summary after cancellation
    std::cout << "\nFlight Summary A001 after cancellation:" << std::endl;
    system.showFlightSummary("A001");

    return 0;
}
