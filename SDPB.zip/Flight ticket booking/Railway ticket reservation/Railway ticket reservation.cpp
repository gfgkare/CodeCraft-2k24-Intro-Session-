// Railway ticket reservation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>

class Ticket {
public:
    int ticketID;
    std::string passengerName;
    std::string journeyDate;
    std::string route;
    std::string coachClass;
    std::string berthPreference;
    double fare;
    
	Ticket(){};
    Ticket(int id, std::string name, std::string date, std::string r, std::string cClass, std::string berth, double f)
        : ticketID(id), passengerName(name), journeyDate(date), route(r), coachClass(cClass), berthPreference(berth), fare(f) {}
};

class Train {
public:
    std::string trainID;
    std::string source;
    std::string destination;
    double distance;
    std::unordered_map<std::string, double> classFare;

	Train(){};
    Train(std::string id, std::string src, std::string dest, double dist)
        : trainID(id), source(src), destination(dest), distance(dist) {
        // Predefined fares for simplicity
        classFare["Sleeper"] = 500.0;
        classFare["AC3"] = 1000.0;
        classFare["AC2"] = 1500.0;
        classFare["AC1"] = 2000.0;
    }
    
    double calculateFare(std::string coachClass) {
        return distance * classFare[coachClass] / 100;  // Basic fare calculation based on distance
    }
};

class BookingSystem {
private:
    std::unordered_map<int, Ticket> m_bookings;
    std::vector<Train> m_trains;
    int m_nextTicketID;

public:
	BookingSystem() : m_nextTicketID(1) {
        // Adding some sample trains
        m_trains.push_back(Train("Train001", "CityA", "CityB", 500));
        m_trains.push_back(Train("Train002", "CityC", "CityD", 800));
    }
    
    void showRoutes() {
    std::cout << "Available Routes: \n";
    for (size_t i = 0; i < m_trains.size(); ++i) {
        std::cout << m_trains[i].trainID << ": " << m_trains[i].source << " -> "
                  << m_trains[i].destination << " (" << m_trains[i].distance << " km)\n";
    }
}
    
    void bookTicket() {
    std::string name, date, route, coachClass, berth;
    showRoutes();
    
    std::cout << "Enter passenger name: ";
    std::cin >> name;
    std::cout << "Enter journey date (DD/MM/YYYY): ";
    std::cin >> date;
    std::cout << "Enter train ID (route): ";
    std::cin >> route;
    std::cout << "Enter coach class (Sleeper, AC3, AC2, AC1): ";
    std::cin >> coachClass;
    std::cout << "Enter berth preference (Lower, Middle, Upper): ";
    std::cin >> berth;

    double fare = 0.0;
    for (size_t i = 0; i < m_trains.size(); ++i) {
        if (m_trains[i].trainID == route) {
            fare = m_trains[i].calculateFare(coachClass);
            break;
        }
    }

    Ticket newTicket(m_nextTicketID++, name, date, route, coachClass, berth, fare);
    m_bookings[newTicket.ticketID] = newTicket;

    std::cout << "Ticket booked successfully! Ticket ID: " << newTicket.ticketID
              << ", Fare: " << newTicket.fare << "\n";
}
    
    void cancelTicket() {
        int ticketID;
        std::cout << "Enter Ticket ID to cancel: ";
        std::cin >> ticketID;
        
        if (m_bookings.find(ticketID) != m_bookings.end()) {
            std::cout << "Ticket canceled successfully!\n";
            m_bookings.erase(ticketID);
        } else {
            std::cout << "Ticket ID not found!\n";
        }
    }
    
    void viewBooking() {
        int ticketID;
        std::cout << "Enter Ticket ID to view: ";
        std::cin >> ticketID;

        if (m_bookings.find(ticketID) != m_bookings.end()) {
            Ticket ticket = m_bookings[ticketID];
            std::cout << "Ticket Details:\n";
            std::cout << "Passenger Name: " << ticket.passengerName << "\n";
            std::cout << "Journey Date: " << ticket.journeyDate << "\n";
            std::cout << "Route: " << ticket.route << "\n";
            std::cout << "Coach Class: " << ticket.coachClass << "\n";
            std::cout << "Berth Preference: " << ticket.berthPreference << "\n";
            std::cout << "Fare: " << ticket.fare << "\n";
        } else {
            std::cout << "Ticket ID not found!\n";
        }
    }
};

int main() {
    BookingSystem system;
    int choice;

    do {
        std::cout << "\nRailway Ticket Booking System\n";
        std::cout << "1. View Routes\n";
        std::cout << "2. Book Ticket\n";
        std::cout << "3. Cancel Ticket\n";
        std::cout << "4. View Booking\n";
        std::cout << "0. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                system.showRoutes();
                break;
            case 2:
                system.bookTicket();
                break;
            case 3:
                system.cancelTicket();
                break;
            case 4:
                system.viewBooking();
                break;
            case 0:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 0);

    return 0;
}

